### Latest Patch
`0.3.2`
```
• Updated for Seekers of the Storm

PLEASE READ THE DISCLAIMER IN THE README
```

<details>
    <summary>Previous patches</summary>

`0.3.1`
```
• Updated bepinex and mmhook dependencies for the Devotion patch
```
This update was kindly contributed by Moffein

`0.3.0`
```
• No longer uses Embedded Assets
• Removed warning spam during loading
• Slightly changed in-air idle animation
• Slightly increased the size of her ass
• Updated R2API dependencies
• Added config file that allows editing some (but not all) of her values
```
    
`0.2.1`
```
• Added CustomEmotesAPI support
```
    
`0.2.0`
```
• Added item displays

• Changed a tooltip in the survivor overview

• Fixed issue causing her to get stuck in the Bullet Heaven looping animation
```

`0.1.1`
```
• Changed Trigger Tap SFX (Thank you Moffein for the suggestion!)

• Crashing Comet's hidden invincibility buff will now extend for 0.3 seconds after the dash is done

• Gun Sling's gunshot SFX should now only play for the client that owns the projectile
```

`0.1.0`
```
• Initial release
```
</details>
