#Latest News

I haven't played this game since before SotS so I'm kinda mentally clocked out right now. Just adding a quick fix for the time being.

# The Deputy

The Deputy is an extremely mobile run-and-gun survivor who whittles enemies down with her revolvers before finishing them off with massive burst damage from her Special.

Tips<br/>
• Use Shooting Star immediately after Crashing Comet to quickly traverse long distances.<br/>
• Get a Wax Quail.<br/>
• Gun Sling can be used to cancel your downwards momentum.

This survivor was inspired by the Ranger from Dungeon & Fighter.

![image](https://user-images.githubusercontent.com/55299061/216573294-edc2b9a6-6252-4f1b-9f7e-c672a16c73e1.png)
![image](https://user-images.githubusercontent.com/55299061/216577065-f5636858-64be-4e57-a220-5b82303c37e8.png)
![image](https://user-images.githubusercontent.com/55299061/216604383-33a8dd7a-779a-45be-9d38-19a9fb58bccc.png)
![image](https://user-images.githubusercontent.com/55299061/216581639-9be53fde-0990-43ae-a258-23bb59d00779.png)

## Contact Me
For feedback and bug reports, please reach out to `bog_rtm` on Discord. You can also find me on the official Risk of Rain 2 modding server.

## Credits
```
• https://twitter.com/Abstrabby
    - Character design + concept art
    
• GEMO
    - Default skin model
    
• rob + TheTimeSweeper
    - Providing the Henry character base template
    
• Mary
    - Early dev build testing
    
• Bog
    - Coding
    - Rigging
    - Animation
    - Skill icons

• Moffein
    - 0.3.1 patch
```

## Planned Updates
```
• Mastery skin
• Logbook entry
• Fix animation smoothing issue
• Add more VFX for pretty much everything
• Add more custom SFX
• Remake icons for Gun Sling and Shooting Star
• Add SFX to lobby intro animation
• General animation polishing
```

----
![DeputyIcon2](https://user-images.githubusercontent.com/55299061/216585851-c6588d0c-18a1-4357-905e-79fb3b1c7fcd.png)
![DeputyDesignSheet](https://user-images.githubusercontent.com/55299061/216585982-0017c887-ac98-40e0-b159-035d79aec083.png)


## DISCLAIMER

In the case that this mod becomes deprecated or unplayable, and I have completely disappeared for an extended period of time and cannot be contacted, I grant full permission to update and maintain this mod to anybody who wishes to do so, as long as proper credit is given to myself and all others who have worked on Deputy. I will do my best to keep the github repo updated with all the latest project files.

## Change Log

Check the changelog tab!
